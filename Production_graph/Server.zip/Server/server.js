
var express = require('express');
var session = require('express-session');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var logger = require('morgan');
var validator = require('express-validator');
var flash = require('connect-flash');
var passport = require('passport');
var localStatergy = require('passport-local').Strategy;
var mongodb = require('mongodb');
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/demoApp');
var db = mongoose.connection;
var Schema = mongoose.Schema;

var userDataSchema = new Schema({
	username: String,
	password: String,
	clientId: String
},{collection:'user_details'});


var graphSchema = new Schema({
	client: String,
	oil: String,
	gas: String,
	water: String,
	date: String
},{collection:'daily_data'});


var wellsSchema = new Schema({
	client: String,
	well: String,
	well_name: String
},{collection:'client_wells'});



let app = express();
let PORT = 8000;

app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));
app.use(cookieParser());
app.use(session({secret: 'atomicbomb',resave: false,saveUninitialized:false}));

app.use(function(req, res, next) {
	 res.header("Access-Control-Allow-Origin", "*");
	 res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
	 res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
	 next();
});

app.get('/graph',function(req,res) {
	let clientId = req.query.id;
	
	let wellId = [];
	
	if (req.query.wellId instanceof Array) {
		wellId = req.query.wellId;
	}
	else {
		wellId.push(req.query.wellId);
	}
	
	console.log('clientId ..'+clientId);
	console.log('wellId ..'+wellId);
	
	var GraphData = mongoose.model('GraphData', graphSchema);
	
	GraphData.find({ 'client': clientId,'wellId': {$in:wellId} }, function (err, dailyData) {
  	  if (err) return handleError(err);
  	  if(dailyData!=undefined){
  		  res.setHeader('Content-Type', 'application/json');
  		  console.log(dailyData);
  		  res.send(dailyData);
  		  res.end();
  	  }
  	  else {
  		  console.log('empty');
  		  res.end();
  	  }// Space Ghost is a talk show host.
  	});
});

app.get('/wells',function(req,res) {
	let clientId = req.query.id;
	
	var wellsData = mongoose.model('WellsData', wellsSchema);
	
	wellsData.find({ 'client': clientId }, function (err, wellsData) {
  	  if (err) return handleError(err);
  	  if(wellsData!=undefined){
  		  res.setHeader('Content-Type', 'application/json');
  		  console.log(wellsData);
  		  res.send(wellsData);
  		  res.end();
  	  }
  	  else {
  		  console.log('empty');
  		  res.end();
  	  }
  	});
});

app.post('/validate', function(req, res) {
	console.log('.... validate ......');
    var UserData = mongoose.model('UserData', userDataSchema);
    UserData.findOne({ 'username': req.body.username }, 'clientId', function (err, userData) {
    	  if (err) return handleError(err);
    	  if(userData!=undefined){
    		  console.log(userData.clientId);
    		  res.write(userData.clientId);
    		  res.end();
    	  }
    	  else {
    		  res.write('none');
    		  res.end();
    	  }// Space Ghost is a talk show host.
    	});
	
});

app.listen(PORT, function() {
	  console.log('Listening at '+ PORT );
});